#booleam 
#check booleam example
print(50 > 40) 
print(50 < 40) 
print(50 == 40) 

#evaluate value and variable
#true
print(bool("this is true")) 
print(bool(9)) 
#false
print(bool("")) 
print(bool(0)) 


#function can return bool
def variable():
    return True
    
print(variable ()) 