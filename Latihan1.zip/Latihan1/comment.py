#this is comment
print("this file is about comment") 

print("the comment but in another form")#hi this comment again

#multiply comment
#multiply comment 1
#multiply comment 2

"""
print("comment with multiple string") 

"""
print("comment before me not get displayed ") 