#python output
print("this is output") 

print('one quotation mark') 

print("no new line", end=" ") 
print("print beside previous output") 

b = 50
a = 50
print("ini angka",b) 
print("ini angka",a) 
print("angka",b,"+",a,"=",b+a)

print("hasil dari angka",b,"+", a," dibagi 50 =",(b+a)/50)