#casting
#wheb you want to specify vary data type

#int
i_1 = int(1) 
i_2 = int(1.0) 
i_3 = int("1"

#float
f_1 = float(1) 
f_2 = float(1.0) 
f_3 = float("1") 
f_4 = float("1.2") 

#string
s_1 = string ("string ") 
s_2 = string (1) 
s_3 = string(1.2) 
