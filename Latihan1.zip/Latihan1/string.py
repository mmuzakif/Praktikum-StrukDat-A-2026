#strinh
print("this is string")

#assign string to variable
b = "hello world"

#quotes in string
print("hello world 'hi dunia' he say") 

#multiline string
print("""hello dunia hello world
hello dunia and hi world earth Saturn coalition
bloom become universe """) 

#string are array
g = " David"
print(g[0]) 

#looping
for x in g:
    print("loop") 

#string len
print(len(g)) 

#slicing
print(g[1:3])
#from the start
print(g[:2])
#from the end
print(g[2:])
#negative
print(g[-2:-1]) 

#modify upper
print(g.upper()) 
#modify lower
print(g.lower()) 
#white space
print(g.strip())
#replace string
print(b.replace("g", "e")) 
#split sspring
print (g.split("v")) 

#string concatenation
print(g + b)