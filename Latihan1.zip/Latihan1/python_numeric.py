#three numeric number in python
b = 2 #int
g = 3.0 #float
f = 4j#complex

#convert
b_complex = complex(b)
print(b_complex) #int to complex
f_int = int(f.real) 
print(f_int) #complex to int