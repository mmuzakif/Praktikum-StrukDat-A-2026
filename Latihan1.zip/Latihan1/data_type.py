#data type
thisis_int = 1
thisis_float = 1.0
thisis_string = "string"
z = 3 + 4j
print(z)

#checking the data type
print(type(thisis_float)) 
print(type(z)) 

#setting data type
float_int = float(thisis_int)
print(float_int) 