#variables python
money = 7000 #int
another_money = "7000" #string
another_1_money = 7.000 #float
print(type(money)) 

#assign variable with variable
float_money = float(money) 
print(float_money) 

#camel case
variableOfHappines = "money"
#snake case
what_is_money = money
#pascal case
CapitalAlphabet = "A"

#multiple value
one,two,three = 1,2,3
print(one,two,three)
this = there = thus = "hmmmmm"
print(thus)

#unpacking
numbers = [1, 2, 3]
numbers1,numbers2,numbers3 = numbers
print(numbers2)

#global variable
glo = "global"
def glo_1():
    print("this is",glo) 
    not_glo = "not global" #this is not global
glo_1()   

