def konverter(konvert):
    print(konvert / 15000)

 
b = 100000
konverter(b)






